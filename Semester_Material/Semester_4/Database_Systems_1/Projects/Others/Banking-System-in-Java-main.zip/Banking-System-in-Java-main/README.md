# Bank_java
Java project with javaFx, MySQL and implementing the MVC architecture.
Editor : intellij


[Rapport java.pdf](https://github.com/OumaymaRedissi/Banking-System-in-Java/files/7908103/Rapport.java.pdf)
