package com.bank.Controllers;


        import javafx.fxml.FXML;
        import javafx.scene.control.Button;
        import javafx.scene.control.PasswordField;
        import javafx.scene.control.TextField;


public class loginController {

    @FXML
    private Button btnConn;

    @FXML
    private TextField tfLogin;

    @FXML
    private PasswordField tfMdp;


}
