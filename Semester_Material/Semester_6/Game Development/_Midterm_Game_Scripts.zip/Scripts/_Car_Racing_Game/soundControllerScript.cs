using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class soundControllerScript : MonoBehaviour
{
    public GameObject mute,unmute;
    
    private bool muteFlag = false;
    void Start()
    {        
        if(muteFlag)
        {            
            mute.SetActive(false);
            unmute.SetActive(true);
            AudioListener.volume = 0;
        }
        else
        {         
            mute.SetActive(true);
            unmute.SetActive(false);
            AudioListener.volume = 1;
        }        
    }

    // Update is called once per frame
    public void muteGame()
    {        
        mute.SetActive(false);
        unmute.SetActive(true);
        AudioListener.volume = 0;
        muteFlag = false;
    }
    public void unmuteGame()
    {
        muteFlag = true;
        mute.SetActive(true);
        unmute.SetActive(false);
        AudioListener.volume = 1;
    }
}
