using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class buttonScript : MonoBehaviour
{    
    public Button btn;

    public void Start()
    {
        btn.onClick.AddListener(clickHandler);
    }
    public void clickHandler()
    {        
        SceneManager.LoadScene("Main_Scene");
    }
}
