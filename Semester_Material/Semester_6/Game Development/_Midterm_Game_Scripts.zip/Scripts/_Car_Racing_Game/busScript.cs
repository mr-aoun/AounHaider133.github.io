using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class BusScript : MonoBehaviour
{
    public Text busHealth;
    public float health = 50;
    public float speedStrength;
    public bool insideObject = false;
    private int numOfStudents = 0;
    public GameObject[] students; 

    public int leftStudentCount = 3,rightStudentCount = 0;   

    public AudioSource hornSound;

    // Start is called before the first frame update
    void Start()
    {
        students = new GameObject[6];
        
        //Extract all the game object and store in array
        for(int i=1;i<7;i++)
        students[i-1] = GameObject.Find("School_Childrens_"+i.ToString());

        busHealth.text = "Student: " + numOfStudents.ToString() + "\nBus Health: " + health.ToString();
        hornSound = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {               
        // Move the bus based on user input
        if (Input.GetKey(KeyCode.UpArrow)) //move forward
        {
            transform.Translate(0, 0, speedStrength);
        }
        if (Input.GetKey(KeyCode.DownArrow)) //move backward
        {
            transform.Translate(0, 0, -speedStrength);
        }
        if (Input.GetKey(KeyCode.LeftArrow)) //move left
        {
            transform.Rotate(0, -speedStrength, 0);
        }
        if (Input.GetKey(KeyCode.RightArrow)) //move right
        {
            transform.Rotate(0, speedStrength, 0);
        }
        if (Input.GetKeyDown(KeyCode.H))
        {
            hornSound.Play();
        }

        // Check if the bus health is zero
        if (health <= 0)
        {
            SceneManager.LoadScene("GameOver_Scene");
        }
        if(numOfStudents == 30)
        {
            SceneManager.LoadScene("GameWin");
        }

        if(insideObject && Input.GetKey(KeyCode.Space))
        {                         
             if(transform.position.z > -60 && rightStudentCount < 3) //right side
             {                
                Destroy(students[rightStudentCount]);
                numOfStudents += 5;
                rightStudentCount++;
                busHealth.text = "Student: " + numOfStudents.ToString() + "\nBus Health: " + health.ToString();
             }
            else if(transform.position.z < -60 && (leftStudentCount > 2 && leftStudentCount < 6)) //left side
            {                
                Destroy(students[leftStudentCount]);
                numOfStudents += 5;
                leftStudentCount++;
                busHealth.text = "Student: " + numOfStudents.ToString() + "\nBus Health: " + health.ToString();
            }    
            insideObject = false;              
        }
    }

    private void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.name.StartsWith("Car") || col.gameObject.name.StartsWith("Truck"))
        {
            health -= 10;
            busHealth.text = "Student: " + numOfStudents.ToString() + "\nBus Health: " + health.ToString();
        }
        if(col.gameObject.name.StartsWith("Pickup_boundary"))
        {                            
                insideObject = true;            
        }
    }
    private void OnCollisionExit(Collision col)
    {
        if(col.gameObject.name.StartsWith("Pickup_boundary"))
        {
            insideObject = false;
        }
    }
}