//Task: provide action for car reached at the end of the road and starts automatically from start
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Runtime.CompilerServices;

public class carScript : MonoBehaviour
{
    public float leftRotateStrength = -0.5f;
    public float rightRotateStrength = 0.5f;

    public AudioSource AlarmAudio;

    float fuelValue = 500;
    public Text fuelText;
    public Text lowFuelText;

    public GameObject drum;

    
    // Start is called before the first frame update
    void Start()
    {
        fuelText.text = "Fuel: " + fuelValue.ToString();
        lowFuelText.text = "";
        AlarmAudio = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
      if(Input.GetKey(KeyCode.UpArrow)) //forward move  
      {
        transform.Translate(0,0,0.5f);
            fuelValue -= 1;
            fuelText.text = "Fuel: " + fuelValue.ToString();
      }
      if(Input.GetKey(KeyCode.LeftArrow)) //left rotation
      {
        transform.Rotate(0,leftRotateStrength,0);
      }
      if(Input.GetKey(KeyCode.RightArrow)) //right rotation
      {
        transform.Rotate(0,rightRotateStrength,0);
      }

      //move the car from ending to starting position again
      Vector3 carPos = transform.position;
      if(carPos.z > 90) //ending position of z: 90
      {
        carPos.z = -90; //starting position of z
        transform.position = carPos;
      }
      if(fuelValue <= 20)
      {
        fuelText.text = "Fuel is Low!";
        AlarmAudio.Play();
      }
      if(fuelValue <= 0)
      {
         SceneManager.LoadScene("GameOver");
      }
      
    }
    private void OnCollisionEnter(Collision col)
    {
      if(col.gameObject.CompareTag("abc"))
      {        
          //Debug.Log("Collided!");
          fuelValue = 500;
          //fuelText.text = "Fuel value is: " + fuelValue.ToString();
          Destroy(col.gameObject);
          //AlarmAudio.mute = true;
        
      }
      if(col.gameObject.name.StartsWith("Car_1") || col.gameObject.name.StartsWith("Car_2") || col.gameObject.name.StartsWith("Bus_1") || col.gameObject.name.StartsWith("Bus_2"))      
      {
        fuelValue -= 5f;
      }
    }
}
