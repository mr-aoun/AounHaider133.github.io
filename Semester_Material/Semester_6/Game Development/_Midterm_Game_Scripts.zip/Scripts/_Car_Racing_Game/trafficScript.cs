using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class trafficScript : MonoBehaviour
{
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(0,0,0.1f);
        Vector3 trafficPos = transform.position;
        if(trafficPos.z > 90)    
        {
            trafficPos.z = -90;
            transform.position = trafficPos;
        }
    }
}
