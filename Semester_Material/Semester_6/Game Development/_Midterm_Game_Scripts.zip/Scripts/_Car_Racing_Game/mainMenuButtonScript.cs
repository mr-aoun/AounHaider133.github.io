using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class mainMenuButtonScript : MonoBehaviour
{
    public AudioSource audioSound;
    void Start()
    {
        audioSound = GetComponent<AudioSource>();
        audioSound.Play();
    }
    public void LoadLevel_1()
    {        
        SceneManager.LoadScene("Main_Scene");
        audioSound.mute = true;
    }
    public void QuitGame()
    {
        Application.Quit();
    }
}
