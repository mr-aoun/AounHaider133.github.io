using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyScript : MonoBehaviour
{
    public GameObject fps;
    Animator anim;
    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        anim.SetTrigger("walk");
    }

    // Update is called once per frame
    void Update()
    {
        transform.LookAt(fps.transform);
        // if(Input.GetKey(KeyCode.J))
        // {
        //     anim.SetTrigger("jump");
        // }
        // if(Input.GetKey(KeyCode.W))
        // {
        //     anim.SetTrigger("walk");
        // }
        // else{
        //     anim.SetTrigger("idle");
        // }
    }
    // public void OnCollisionEnter(Collision col)
    // {
    //     if(col.gameObject.name.StartsWith("bullet"))
    //     {            
    //         anim.SetTrigger("die");
    //     }
    //     Destroy(col.gameObject);
    // }
    public void die()
    {
        anim.SetTrigger("die");
    }
}
