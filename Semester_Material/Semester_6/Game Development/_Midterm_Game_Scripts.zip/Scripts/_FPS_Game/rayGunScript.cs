using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rayGunScript : MonoBehaviour
{
    public GameObject fpsCam;
    public float range = 500f;
    public GameObject bulletFire;
    // Start is called before the first frame update
    void Start()
    {
        bulletFire.SetActive(false);
        
    }

    // Update is called once per frame
    void Update()
    {
      if(Input.GetMouseButtonDown(0))   
      {
        shoot();
        bulletFire.SetActive(true);
        Instantiate(bulletFire,transform.position,transform.rotation);
      }
    }
    public void shoot()
    {
        RaycastHit hit;        
        if(Physics.Raycast(fpsCam.transform.position,transform.forward,out hit,range))
        {
          // Debug.DrawRay(transform.position,transform.forward*hit.distance,Color.red );
          
            if(hit.transform.tag == "enemy")
            {
                // Debug.DrawRay(transform.position,transform.forward*hit.distance,Color.green );
                enemyScript enemy = hit.transform.GetComponent<enemyScript>();
                Debug.Log("Collided!");
                enemy.die();
            }
        }
    }
}
