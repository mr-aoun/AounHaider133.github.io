using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class footballScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.RightArrow))
        {
            transform.Translate(0.5f,0,0);
            transform.Rotate(0,0,0.5f);
        }
        if(Input.GetKeyDown(KeyCode.LeftArrow))
        {
            transform.Translate(-0.5f,0,0);
            transform.Rotate(0,0,-0.5f);
        }
        if(Input.GetKey(KeyCode.B)) //backward
        {
            transform.Translate(0,0,-0.5f);
            transform.Rotate(-0.5f,0,0);
        }
        if(Input.GetKey(KeyCode.W)) //forward
        {
            transform.Translate(0,0,0.5f);
            transform.Rotate(0.5f,0,0);
        }
        if(Input.GetKey(KeyCode.UpArrow))
        {
            transform.Translate(0,0.5f,0);
            transform.Rotate(0,0.5f,0);
        }
        if(Input.GetKey(KeyCode.DownArrow))
        {
            transform.Translate(0,-0.5f,0);
            transform.Rotate(0,0.5f,0);
        }
    }
}
