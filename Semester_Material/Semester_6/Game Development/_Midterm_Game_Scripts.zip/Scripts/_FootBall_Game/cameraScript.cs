using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cameraScript : MonoBehaviour
{
    public GameObject football;
    Vector3 offset;
    // Start is called before the first frame update
    void Start()
    {
        offset = transform.position - football.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = offset + football.transform.position;
    }
}
