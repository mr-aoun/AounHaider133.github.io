using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cubeScript : MonoBehaviour
{
    public Vector3 direction = Vector3.up;
    float speed = 0.1f;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //Start co-routine
        StartCoroutine(RunEveryNFrames(100));
        
        //move object independent of the frame rate
        var movement = direction * speed;
        movement *= Time.deltaTime;
        this.transform.Translate(movement);        
    }
    IEnumerator RunEveryNFrames(int n)
    {
        yield return null;

        if(Time.frameCount%n == 0)
        {
            Debug.LogFormat("Frame {0}!",Time.frameCount);
        }
    }
    
}