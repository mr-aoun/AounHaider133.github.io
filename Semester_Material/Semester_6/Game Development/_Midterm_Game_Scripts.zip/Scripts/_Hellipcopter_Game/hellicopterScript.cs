using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class hellicopterScript : MonoBehaviour
{
    public GameObject muteButton;
    public GameObject unmuteButton;

    public Text scoreText;

    public float score = 0;

    public static bool muteflag;

    public AudioSource audio;

    // public bulletScript enemy;
    public GameObject bullet;
    // Start is called before the first frame update
    void Start()
    {
        audio = GetComponent<AudioSource>();
        scoreText.text = "Score: "+score.ToString();
        if(muteflag == true)
        {
            audio.mute = true;
            muteButton.SetActive(false);            
            audio.volume = 0;
        }
        else
        {
            audio.mute = false;
            unmuteButton.SetActive(false);
            audio.volume = 1;
        }
        
    }

    public void mutegame()
    {
        audio.mute = true;
        muteButton.SetActive(false);
        unmuteButton.SetActive(true);
        AudioListener.volume = 0;
        muteflag = true;
    }
    public void unmutegame()
    {
        if(muteflag == true)
        {
            audio.mute = false;
            muteButton.SetActive(true);
            unmuteButton.SetActive(false);
            AudioListener.volume = 1;
            muteflag = false;
        }
    }

    // Update is called once per frame
    void Update()
    {        
        if(Input.GetKey(KeyCode.LeftArrow))
        {
            transform.Rotate(0,-1,0);
        }        
        if(Input.GetKey(KeyCode.RightArrow))
        {
            transform.Rotate(0,1,0);
        }     
        if(Input.GetKey(KeyCode.UpArrow))
        {
            transform.Translate(0,0,1);
        }
        if(Input.GetKey(KeyCode.DownArrow))
        {
            transform.Translate(0,0,-1);
        }

        if(Input.GetKey(KeyCode.W))
        {
            transform.Translate(0,1,0);
        }
        if(Input.GetKey(KeyCode.S))
        {
            transform.Translate(0,-1,0);
        }
        if(Input.GetKey(KeyCode.Space))
        {
            Instantiate(bullet,transform.position,transform.rotation);
            if(bulletScript.collided)
            {
                score += 10;
                scoreText.text = "Score: "+score.ToString();
                bulletScript.collided = false;
            }
        }
    }
    public void OnCollisionEnter(Collision col)
    {
        if(col.gameObject.name.StartsWith("Enemy"))
          SceneManager.LoadScene(2);
    }
}
