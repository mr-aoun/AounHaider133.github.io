using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class audioscript : MonoBehaviour
{
    public GameObject mutebutton;
    public GameObject unmutebutton;
    public AudioSource muteaudio;
    public static bool muteflag;
    // Start is called before the first frame update
    void Start()
    {
        muteaudio = GetComponent<AudioSource>();
        if (muteflag == true)
        {
            muteaudio.mute = true;
            mutebutton.SetActive(false);
            muteaudio.volume = 0;
        }

        if (muteflag == false)
        {
            muteaudio.mute = false;
            unmutebutton.SetActive(false);
            muteaudio.volume = 1;
        }
        
    }
    public void mutegame()
    {
        muteaudio.mute = true;
        mutebutton.SetActive(false);
        unmutebutton.SetActive(true);
        muteflag = true;
        AudioListener.volume = 0;
    }
    public void unmutegame()
    {
        if (muteflag == true)
        {
            muteaudio.mute = false;
            mutebutton.SetActive(true);
            unmutebutton.SetActive(false);
            muteflag = false;
            AudioListener.volume = 1;
        }
    }

    public void playlevel1()
    {        
        SceneManager.LoadScene(1);
    }
}
