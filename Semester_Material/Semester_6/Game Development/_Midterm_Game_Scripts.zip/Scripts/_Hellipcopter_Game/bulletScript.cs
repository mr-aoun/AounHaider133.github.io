using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bulletScript : MonoBehaviour
{
    public GameObject explosion;
    [SerializeField]
    public static bool collided = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(0,0,1);
    }
    public void OnCollisionEnter(Collision col)
    {
        if(col.gameObject.name.StartsWith("Enemy"))
        {            
            Destroy(col.gameObject); //destroy the enemy
            Instantiate(explosion,transform.position,transform.rotation);
            collided = true;
        }
        Destroy(transform.gameObject); //destroy bullet clone        
    }
}
